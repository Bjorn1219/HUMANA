@echo off
setlocal
set APP_HOME=%~dp0
set GRADLE_VERSION=8.7
set DIST=%USERPROFILE%\.gradle\humana-gradle\%GRADLE_VERSION%
set GRADLE=%DIST%\gradle-%GRADLE_VERSION%\bin\gradle.bat
if not exist "%GRADLE%" (
  if not exist "%DIST%" mkdir "%DIST%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.7-bin.zip' -OutFile '%DIST%\gradle.zip'"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%DIST%\gradle.zip' '%DIST%'"
  del "%DIST%\gradle.zip"
)
cd /d "%APP_HOME%"
call "%GRADLE%" %*
endlocal
