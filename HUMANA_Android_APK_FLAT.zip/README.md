# HUMANA - proyecto Android

Proyecto Android nativo Java. Este ZIP está preparado para compiladores web que esperan el proyecto Android directamente en la raíz del ZIP.

Salida: APK de depuración mediante `assembleDebug`.
