package com.humana.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;

public class HumanaMonitorService extends Service {
    private static final String CHANNEL_ID = "HUMANA";
    private static final int NOTIFICATION_ID = 1001;
    private final Handler handler = new Handler();

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();

        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, openIntent,
                Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);

        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("HUMANA está contigo")
                .setContentText("Servicio de acompañamiento activo")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();

        startForeground(NOTIFICATION_ID, notification);

        handler.postDelayed(() -> notifyMoment(
                "Hay señales compatibles con tensión. ¿Quieres hacer una pausa de 2 minutos?"), 20000);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "HUMANA", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Avisos de HUMANA");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void notifyMoment(String message) {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager == null) return;
        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("HUMANA · momento de calma")
                .setContentText(message)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setAutoCancel(true)
                .build();
        manager.notify(2002, notification);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
